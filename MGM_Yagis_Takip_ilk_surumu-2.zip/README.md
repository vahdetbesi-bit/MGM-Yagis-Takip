MGM Yağış Takip ilk prototipi.
Tarih + çoklu ekran görüntüsü + cihaz üzerinde OCR + 0,8 mm eşik.
Bu sürüm henüz kalıcı günlük kayıt/veritabanı ekranını içermiyor; sonraki sürümde eklenecek.
