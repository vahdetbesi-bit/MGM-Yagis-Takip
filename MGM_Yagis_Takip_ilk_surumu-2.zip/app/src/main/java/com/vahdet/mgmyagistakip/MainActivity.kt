package com.vahdet.mgmyagistakip

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val selectedUris = mutableListOf<Uri>()
    private lateinit var dateEdit: EditText
    private lateinit var status: TextView
    private lateinit var result: TextView

    private val picker = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        selectedUris.clear()
        selectedUris.addAll(uris)
        status.text = "${uris.size} fotoğraf seçildi."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        root.addView(TextView(this).apply {
            text = "MGM Yağış Takip — İlk Sürüm"
            textSize = 24f
        })

        dateEdit = EditText(this).apply {
            hint = "Tarih (GG.AA.YYYY)"
            setText(String.format(Locale("tr","TR"), "%02d.%02d.%04d",
                java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH),
                java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1,
                java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)))
        }
        root.addView(dateEdit)

        root.addView(Button(this).apply {
            text = "📷 MGM fotoğraflarını seç"
            setOnClickListener { picker.launch("image/*") }
        })

        status = TextView(this).apply { text = "Henüz fotoğraf seçilmedi." }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "🔎 Fotoğrafları tara"
            setOnClickListener { scanAll() }
        })

        result = TextView(this).apply {
            text = "Sonuçlar burada görünecek."
            textSize = 17f
            setPadding(0, 20, 0, 0)
        }
        val scroll = ScrollView(this)
        scroll.addView(result)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun scanAll() {
        if (selectedUris.isEmpty()) {
            Toast.makeText(this, "Önce fotoğraf seç.", Toast.LENGTH_SHORT).show()
            return
        }

        result.text = "Taranıyor..."
        val all = StringBuilder()
        var remaining = selectedUris.size

        selectedUris.forEach { uri ->
            try {
                recognizer.process(InputImage.fromFilePath(this, uri))
                    .addOnSuccessListener { text ->
                        all.append("\n--- FOTOĞRAF ---\n").append(text.text)
                    }
                    .addOnFailureListener { e ->
                        all.append("\n[OCR hatası: ${e.message}]\n")
                    }
                    .addOnCompleteListener {
                        remaining--
                        if (remaining == 0) showParsed(all.toString())
                    }
            } catch (e: Exception) {
                remaining--
                if (remaining == 0) showParsed(all.toString())
            }
        }
    }

    private fun showParsed(text: String) {
        val rows = parseRainRows(text)
        result.text = buildString {
            append("Tarih: ").append(dateEdit.text).append("\n\n")
            if (rows.isEmpty()) {
                append("0,8 mm ve üzeri kayıt bulunamadı.")
            } else {
                rows.forEach { (station, mm) ->
                    append(station).append("  →  ")
                        .append(String.format(Locale("tr","TR"), "%.1f", mm))
                        .append(" mm\n")
                }
            }
        }
    }

    private fun parseRainRows(text: String): LinkedHashMap<String, Double> {
        val out = LinkedHashMap<String, Double>()
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val numberRegex = Regex("""(?<!\d)(\d{1,3}(?:[.,]\d{1,2}))(?!\d)""")
        var buffer = ""

        for (line in lines) {
            val match = numberRegex.findAll(line).lastOrNull()
            if (match != null) {
                val mm = match.groupValues[1].replace(',', '.').toDoubleOrNull()
                val station = (buffer + " " + line.substring(0, match.range.first))
                    .replace(Regex("\\s+"), " ").trim()
                if (mm != null && mm >= 0.8 && station.length > 3) {
                    val key = station.uppercase(Locale("tr","TR"))
                    if (!out.containsKey(key)) out[key] = mm
                    else if (out[key] != mm) out["$key [ÇAKIŞMA]"] = mm
                }
                buffer = ""
            } else {
                buffer = (buffer + " " + line).trim()
            }
        }
        return out
    }
}
